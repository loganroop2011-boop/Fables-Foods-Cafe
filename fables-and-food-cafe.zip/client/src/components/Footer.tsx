/**
 * Footer — Fables & Food Café
 * Design: Warm Literary Maximalism — closing chapter feel
 */

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer
      className="py-16"
      style={{ background: "oklch(0.14 0.03 45)", borderTop: "1px solid oklch(0.97 0.018 78 / 0.06)" }}
    >
      <div className="container">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand column */}
          <div>
            <h3
              className="text-2xl font-bold mb-2"
              style={{
                fontFamily: "var(--font-display)",
                color: "oklch(0.97 0.018 78)",
              }}
            >
              Fables &amp; Food
            </h3>
            <p
              className="text-xs tracking-[0.25em] uppercase mb-4"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.72 0.14 65)",
              }}
            >
              Café · West End · Vancouver
            </p>
            <p
              className="text-sm leading-relaxed"
              style={{
                fontFamily: "var(--font-body)",
                color: "oklch(0.55 0.025 65)",
                fontStyle: "italic",
              }}
            >
              Every fable has a flavour — and every flavour has a tale to tell.
            </p>
          </div>

          {/* Hours column */}
          <div>
            <p
              className="text-xs tracking-[0.25em] uppercase mb-5"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.72 0.14 65)",
              }}
            >
              Hours
            </p>
            <div className="space-y-2">
              {[
                { days: "Mon – Thu, Sun", hours: "8:00 am – 6:00 pm" },
                { days: "Fri – Sat", hours: "8:00 am – 7:00 pm" },
              ].map((row) => (
                <div key={row.days} className="flex justify-between gap-4">
                  <span
                    className="text-sm"
                    style={{
                      fontFamily: "var(--font-ui)",
                      color: "oklch(0.65 0.025 65)",
                    }}
                  >
                    {row.days}
                  </span>
                  <span
                    className="text-sm font-medium"
                    style={{
                      fontFamily: "var(--font-ui)",
                      color: "oklch(0.80 0.025 65)",
                    }}
                  >
                    {row.hours}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Contact column */}
          <div>
            <p
              className="text-xs tracking-[0.25em] uppercase mb-5"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.72 0.14 65)",
              }}
            >
              Find Us
            </p>
            <div className="space-y-3">
              <a
                href="https://maps.google.com/?q=1016+Cardero+St,+Vancouver,+BC+V6G+2H1"
                target="_blank"
                rel="noopener noreferrer"
                className="block text-sm leading-relaxed hover:opacity-70 transition-opacity"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "oklch(0.65 0.025 65)",
                  textDecoration: "none",
                }}
              >
                1016 Cardero St<br />
                Vancouver, BC V6G 2H1
              </a>
              <a
                href="tel:+16047043572"
                className="block text-sm hover:opacity-70 transition-opacity"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.65 0.025 65)",
                  textDecoration: "none",
                }}
              >
                +1 (604) 704-3572
              </a>
              <a
                href="https://www.instagram.com/fablesandfoodcafe/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm hover:opacity-70 transition-opacity"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.72 0.14 65)",
                  textDecoration: "none",
                }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                  <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                </svg>
                @fablesandfoodcafe
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="pt-8 flex flex-col md:flex-row justify-between items-center gap-4"
          style={{ borderTop: "1px solid oklch(0.97 0.018 78 / 0.08)" }}
        >
          <p
            className="text-xs"
            style={{
              fontFamily: "var(--font-ui)",
              color: "oklch(0.42 0.025 65)",
            }}
          >
            © {year} Fables &amp; Food Café. All rights reserved.
          </p>
          <p
            className="text-xs"
            style={{
              fontFamily: "var(--font-ui)",
              color: "oklch(0.42 0.025 65)",
            }}
          >
            1016 Cardero St · West End · Vancouver, BC
          </p>
        </div>
      </div>
    </footer>
  );
}
