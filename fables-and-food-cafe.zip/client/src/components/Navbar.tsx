/**
 * Navbar — Fables & Food Café
 * Design: Warm Literary Maximalism
 * Transparent over hero, transitions to espresso background on scroll
 */

import { useEffect, useState } from "react";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Home", href: "#home" },
    { label: "About", href: "#about" },
    { label: "Menu", href: "#menu" },
    { label: "Visit", href: "#visit" },
  ];

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: scrolled
          ? "oklch(0.18 0.04 45 / 0.97)"
          : "transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        borderBottom: scrolled ? "1px solid oklch(0.97 0.018 78 / 0.08)" : "none",
      }}
    >
      <div className="container">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo / Wordmark */}
          <a
            href="#home"
            className="flex flex-col leading-none"
            style={{ textDecoration: "none" }}
          >
            <span
              className="text-xl md:text-2xl font-bold tracking-tight"
              style={{
                fontFamily: "var(--font-display)",
                color: "oklch(0.97 0.018 78)",
              }}
            >
              Fables &amp; Food
            </span>
            <span
              className="text-xs tracking-[0.25em] uppercase"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.72 0.14 65)",
              }}
            >
              Café · West End
            </span>
          </a>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-medium tracking-wide transition-colors duration-200 hover:opacity-70 relative group"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.97 0.018 78)",
                  textDecoration: "none",
                }}
              >
                {link.label}
                <span
                  className="absolute -bottom-1 left-0 h-px w-0 group-hover:w-full transition-all duration-300"
                  style={{ background: "oklch(0.72 0.14 65)" }}
                />
              </a>
            ))}
            <a
              href="https://www.instagram.com/fablesandfoodcafe/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-sm font-medium px-4 py-2 transition-all duration-200 hover:opacity-80"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.18 0.04 45)",
                background: "oklch(0.72 0.14 65)",
                borderRadius: "2px",
                textDecoration: "none",
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
              </svg>
              Instagram
            </a>
          </nav>

          {/* Mobile menu button */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="block w-6 h-px transition-all duration-300"
                style={{
                  background: "oklch(0.97 0.018 78)",
                  transform:
                    menuOpen
                      ? i === 0
                        ? "rotate(45deg) translate(3px, 3px)"
                        : i === 1
                        ? "scaleX(0)"
                        : "rotate(-45deg) translate(3px, -3px)"
                      : "none",
                  opacity: menuOpen && i === 1 ? 0 : 1,
                }}
              />
            ))}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      <div
        className="md:hidden overflow-hidden transition-all duration-400"
        style={{
          maxHeight: menuOpen ? "300px" : "0",
          background: "oklch(0.18 0.04 45 / 0.98)",
          backdropFilter: "blur(12px)",
        }}
      >
        <div className="container py-6 flex flex-col gap-4">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="text-base font-medium py-2 transition-colors duration-200"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.97 0.018 78)",
                textDecoration: "none",
                borderBottom: "1px solid oklch(0.97 0.018 78 / 0.08)",
              }}
            >
              {link.label}
            </a>
          ))}
          <a
            href="https://www.instagram.com/fablesandfoodcafe/"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-medium py-2"
            style={{
              fontFamily: "var(--font-ui)",
              color: "oklch(0.72 0.14 65)",
              textDecoration: "none",
            }}
          >
            @fablesandfoodcafe on Instagram
          </a>
        </div>
      </div>
    </header>
  );
}
