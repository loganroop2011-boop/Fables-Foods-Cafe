/**
 * Fables & Food Café — Home Page
 * Design: Warm Literary Maximalism
 * Colors: Espresso (#1E1410 equiv), Parchment cream, Amber gold, Sage, Terracotta
 * Fonts: Playfair Display (display), Lora (body), DM Sans (UI)
 */

import { useEffect, useRef, useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const HERO_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663748099332/Z8GJVVgxG7UH8gpiqXZotN/hero-cafe-hNgbNi9goqgJoUDuXjaqZT.webp";
const COFFEE_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663748099332/Z8GJVVgxG7UH8gpiqXZotN/coffee-hero-Ku4DxTMHHYoZZMkJJYKCXj.webp";
const FOOD_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663748099332/Z8GJVVgxG7UH8gpiqXZotN/food-spread-dLAo7vADPeq9FTtTpMCdp5.webp";
const EXTERIOR_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663748099332/Z8GJVVgxG7UH8gpiqXZotN/cafe-exterior-4ZPFzBv7iVrwNByR9aAMAw.webp";
const PASTRY_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663748099332/Z8GJVVgxG7UH8gpiqXZotN/pastry-closeup-CuXYgtyVXzNrRRhiu4uas4.webp";

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          el.classList.add("visible");
          observer.disconnect();
        }
      },
      { threshold: 0.12 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return ref;
}

const menuItems = [
  {
    category: "Coffee & Drinks",
    icon: "☕",
    items: [
      { name: "Espresso", desc: "Single origin, pulled to perfection" },
      { name: "Latte", desc: "Silky steamed milk, house espresso blend" },
      { name: "Matcha Latte", desc: "Ceremonial grade, oat or whole milk" },
      { name: "Pour Over", desc: "Rotating single origin selection" },
      { name: "Chai Latte", desc: "House-spiced, warming and aromatic" },
    ],
  },
  {
    category: "Food",
    icon: "🍳",
    items: [
      { name: "Avocado Toast", desc: "Sourdough, microgreens, lemon zest, chili flakes" },
      { name: "Eggs Benedict", desc: "Poached eggs, hollandaise, toasted English muffin" },
      { name: "Granola Bowl", desc: "House granola, seasonal fruit, yogurt, honey" },
      { name: "Smoked Salmon Bagel", desc: "Cream cheese, capers, red onion, dill" },
      { name: "Grilled Cheese", desc: "Three cheese blend, sourdough, tomato jam" },
    ],
  },
  {
    category: "Pastries & Sweets",
    icon: "🥐",
    items: [
      { name: "Butter Croissant", desc: "Freshly baked, flaky and golden" },
      { name: "Pain au Chocolat", desc: "Dark chocolate, laminated dough" },
      { name: "Cinnamon Roll", desc: "House-made, cream cheese glaze" },
      { name: "Banana Loaf", desc: "Moist, walnut, brown butter" },
      { name: "Seasonal Tart", desc: "Ask your barista for today's selection" },
    ],
  },
];

export default function Home() {
  const [heroLoaded, setHeroLoaded] = useState(false);
  const [menuTab, setMenuTab] = useState(0);

  const aboutRef = useReveal();
  const menuRef = useReveal();
  const storyRef = useReveal();
  const hoursRef = useReveal();
  const visitRef = useReveal();

  return (
    <div className="min-h-screen" style={{ fontFamily: "var(--font-body)" }}>
      <Navbar />

      {/* ── HERO ── */}
      <section id="home" className="relative h-screen min-h-[600px] flex items-end overflow-hidden">
        {/* Background image */}
        <div className="absolute inset-0">
          <img
            src={HERO_IMG}
            alt="Fables & Food Café interior"
            className="w-full h-full object-cover"
            style={{
              filter: "brightness(0.55)",
              transition: "opacity 0.8s ease",
              opacity: heroLoaded ? 1 : 0,
            }}
            onLoad={() => setHeroLoaded(true)}
          />
          {/* Warm vignette gradient */}
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to top, oklch(0.12 0.04 45 / 0.92) 0%, oklch(0.12 0.04 45 / 0.5) 40%, transparent 70%)",
            }}
          />
        </div>

        {/* Hero content */}
        <div className="relative z-10 container pb-20 md:pb-28">
          <div className="max-w-3xl">
            <p
              className="mb-4 tracking-[0.25em] uppercase text-sm font-medium"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.85 0.10 75)",
                animationDelay: "0.1s",
              }}
            >
              West End · Vancouver
            </p>
            <h1
              className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.05] mb-6"
              style={{
                fontFamily: "var(--font-display)",
                color: "oklch(0.97 0.018 78)",
              }}
            >
              Fables &amp;{" "}
              <span
                className="italic"
                style={{ color: "oklch(0.85 0.10 75)" }}
              >
                Food
              </span>{" "}
              Café
            </h1>
            <p
              className="text-lg md:text-xl leading-relaxed mb-10 max-w-xl"
              style={{
                fontFamily: "var(--font-body)",
                color: "oklch(0.88 0.015 75)",
              }}
            >
              Every fable has a flavour — and every flavour has a tale to tell.
              A neighbourhood café where stories begin over coffee.
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#menu"
                className="inline-flex items-center gap-2 px-8 py-3.5 font-semibold text-sm tracking-wide transition-all duration-200 hover:scale-[1.03] active:scale-[0.97]"
                style={{
                  fontFamily: "var(--font-ui)",
                  background: "oklch(0.58 0.13 38)",
                  color: "oklch(0.97 0.018 78)",
                  borderRadius: "2px",
                }}
              >
                View Menu
              </a>
              <a
                href="#visit"
                className="inline-flex items-center gap-2 px-8 py-3.5 font-semibold text-sm tracking-wide border transition-all duration-200 hover:bg-white/10 active:scale-[0.97]"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.97 0.018 78)",
                  borderColor: "oklch(0.97 0.018 78 / 0.5)",
                  borderRadius: "2px",
                }}
              >
                Find Us
              </a>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 right-8 z-10 flex flex-col items-center gap-2 opacity-60">
          <span
            className="text-xs tracking-[0.2em] uppercase"
            style={{ fontFamily: "var(--font-ui)", color: "oklch(0.97 0.018 78)" }}
          >
            Scroll
          </span>
          <div
            className="w-px h-12"
            style={{
              background:
                "linear-gradient(to bottom, oklch(0.97 0.018 78), transparent)",
            }}
          />
        </div>
      </section>

      {/* ── TAGLINE BAND ── */}
      <section
        className="py-6 overflow-hidden"
        style={{ background: "oklch(0.58 0.13 38)" }}
      >
        <div className="flex gap-16 animate-marquee whitespace-nowrap">
          {Array.from({ length: 8 }).map((_, i) => (
            <span
              key={i}
              className="text-sm tracking-[0.3em] uppercase shrink-0"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.97 0.018 78)",
              }}
            >
              Coffee &amp; Conversation &nbsp;✦&nbsp; Fresh Baked Daily &nbsp;✦&nbsp; West End Neighbourhood Café &nbsp;✦&nbsp; Open Every Day
            </span>
          ))}
        </div>
      </section>

      {/* ── ABOUT / STORY ── */}
      <section id="about" className="py-24 md:py-32" style={{ background: "oklch(0.97 0.018 78)" }}>
        <div className="container">
          <div ref={aboutRef} className="reveal grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Image side */}
            <div className="relative">
              <div
                className="aspect-[4/5] overflow-hidden"
                style={{ borderRadius: "1px" }}
              >
                <img
                  src={FOOD_IMG}
                  alt="Brunch spread at Fables & Food Café"
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.04]"
                />
              </div>
              {/* Floating quote card */}
              <div
                className="absolute -bottom-8 -right-4 md:-right-8 p-6 max-w-[220px] shadow-xl"
                style={{
                  background: "oklch(0.72 0.14 65)",
                  borderRadius: "1px",
                }}
              >
                <p
                  className="text-3xl leading-none mb-2"
                  style={{
                    fontFamily: "var(--font-display)",
                    color: "oklch(0.18 0.04 45)",
                  }}
                >
                  "
                </p>
                <p
                  className="text-sm leading-relaxed"
                  style={{
                    fontFamily: "var(--font-body)",
                    color: "oklch(0.18 0.04 45)",
                    fontStyle: "italic",
                  }}
                >
                  A local family who truly believes in community, connection, and keeping this special place alive.
                </p>
              </div>
            </div>

            {/* Text side */}
            <div className="pt-8 md:pt-0">
              <p
                className="text-xs tracking-[0.3em] uppercase mb-4"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.58 0.13 38)",
                }}
              >
                Our Story
              </p>
              <h2
                className="text-4xl md:text-5xl font-bold leading-tight mb-6"
                style={{
                  fontFamily: "var(--font-display)",
                  color: "oklch(0.22 0.03 45)",
                }}
              >
                A New Chapter
                <br />
                <span className="italic" style={{ color: "oklch(0.58 0.13 38)" }}>
                  for Cardero St.
                </span>
              </h2>
              <div
                className="space-y-4 text-base leading-relaxed"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "oklch(0.38 0.04 55)",
                }}
              >
                <p>
                  Fables &amp; Food Café is a beloved neighbourhood spot in Vancouver's West End, now entering a new era under local family ownership. We believe every corner café has a story worth telling — and ours is one of community, warmth, and really good coffee.
                </p>
                <p>
                  Inspired by the magic of fables, we've created a space where you can slow down, connect with your neighbours, and find comfort in something made with care. Whether you're here for your morning ritual or an afternoon escape, there's always a seat waiting for you.
                </p>
              </div>
              <div
                className="mt-8 pt-8 flex gap-10"
                style={{ borderTop: "1px solid oklch(0.87 0.03 75)" }}
              >
                {[
                  { num: "8am", label: "Opens Daily" },
                  { num: "7 Days", label: "A Week" },
                  { num: "West End", label: "Vancouver" },
                ].map((stat) => (
                  <div key={stat.label}>
                    <p
                      className="text-2xl font-bold"
                      style={{
                        fontFamily: "var(--font-display)",
                        color: "oklch(0.58 0.13 38)",
                      }}
                    >
                      {stat.num}
                    </p>
                    <p
                      className="text-xs tracking-wide uppercase mt-1"
                      style={{
                        fontFamily: "var(--font-ui)",
                        color: "oklch(0.50 0.04 60)",
                      }}
                    >
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── MENU ── */}
      <section
        id="menu"
        className="py-24 md:py-32"
        style={{ background: "oklch(0.22 0.03 45)" }}
      >
        <div className="container">
          <div ref={menuRef} className="reveal">
            {/* Section header */}
            <div className="text-center mb-14">
              <p
                className="text-xs tracking-[0.3em] uppercase mb-4"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.72 0.14 65)",
                }}
              >
                What We Serve
              </p>
              <h2
                className="text-4xl md:text-5xl font-bold mb-4"
                style={{
                  fontFamily: "var(--font-display)",
                  color: "oklch(0.97 0.018 78)",
                }}
              >
                Our Menu
              </h2>
              <p
                className="text-base max-w-md mx-auto"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "oklch(0.70 0.025 65)",
                  fontStyle: "italic",
                }}
              >
                Made with care, inspired by story.
              </p>
            </div>

            {/* Tab buttons */}
            <div className="flex justify-center gap-2 mb-12 flex-wrap">
              {menuItems.map((cat, i) => (
                <button
                  key={cat.category}
                  onClick={() => setMenuTab(i)}
                  className="px-6 py-2.5 text-sm font-medium tracking-wide transition-all duration-200"
                  style={{
                    fontFamily: "var(--font-ui)",
                    borderRadius: "2px",
                    background:
                      menuTab === i
                        ? "oklch(0.58 0.13 38)"
                        : "oklch(0.30 0.04 45)",
                    color:
                      menuTab === i
                        ? "oklch(0.97 0.018 78)"
                        : "oklch(0.75 0.025 65)",
                    border: "none",
                  }}
                >
                  {cat.icon} {cat.category}
                </button>
              ))}
            </div>

            {/* Menu items grid */}
            <div className="grid md:grid-cols-2 gap-px" style={{ background: "oklch(0.30 0.04 45)" }}>
              {menuItems[menuTab].items.map((item, i) => (
                <div
                  key={item.name}
                  className="p-6 group transition-colors duration-200"
                  style={{
                    background: "oklch(0.22 0.03 45)",
                    animationDelay: `${i * 60}ms`,
                  }}
                >
                  <div className="flex justify-between items-start gap-4">
                    <div>
                      <h3
                        className="text-lg font-semibold mb-1 group-hover:text-amber-400 transition-colors"
                        style={{
                          fontFamily: "var(--font-display)",
                          color: "oklch(0.93 0.018 78)",
                        }}
                      >
                        {item.name}
                      </h3>
                      <p
                        className="text-sm leading-relaxed"
                        style={{
                          fontFamily: "var(--font-body)",
                          color: "oklch(0.62 0.025 65)",
                          fontStyle: "italic",
                        }}
                      >
                        {item.desc}
                      </p>
                    </div>
                    <div
                      className="w-8 h-px mt-3 shrink-0 transition-all duration-300 group-hover:w-12"
                      style={{ background: "oklch(0.72 0.14 65)" }}
                    />
                  </div>
                </div>
              ))}
            </div>

            <p
              className="text-center mt-8 text-sm"
              style={{
                fontFamily: "var(--font-ui)",
                color: "oklch(0.55 0.025 65)",
              }}
            >
              Menu items may vary seasonally. Ask your barista about today's specials.
            </p>
          </div>
        </div>
      </section>

      {/* ── ATMOSPHERE / GALLERY ── */}
      <section
        ref={storyRef}
        className="reveal py-24 md:py-32"
        style={{ background: "oklch(0.91 0.03 75)" }}
      >
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Text side */}
            <div>
              <p
                className="text-xs tracking-[0.3em] uppercase mb-4"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.58 0.13 38)",
                }}
              >
                The Atmosphere
              </p>
              <h2
                className="text-4xl md:text-5xl font-bold leading-tight mb-6"
                style={{
                  fontFamily: "var(--font-display)",
                  color: "oklch(0.22 0.03 45)",
                }}
              >
                Your Corner
                <br />
                <span className="italic" style={{ color: "oklch(0.58 0.13 38)" }}>
                  of the West End
                </span>
              </h2>
              <p
                className="text-base leading-relaxed mb-6"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "oklch(0.38 0.04 55)",
                }}
              >
                Nestled on Cardero Street, we're the kind of place where regulars have their own mugs and strangers become friends. Come in with a book, a laptop, or just yourself — there's no rush here.
              </p>
              <p
                className="text-base leading-relaxed"
                style={{
                  fontFamily: "var(--font-body)",
                  color: "oklch(0.38 0.04 55)",
                }}
              >
                We're proud to be part of Vancouver's West End community — a neighbourhood full of character, creativity, and kindness.
              </p>
              <a
                href="https://www.instagram.com/fablesandfoodcafe/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 mt-8 text-sm font-medium tracking-wide transition-all duration-200 hover:gap-3"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.58 0.13 38)",
                }}
              >
                Follow us on Instagram
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M12 5l7 7-7 7" />
                </svg>
              </a>
            </div>

            {/* Images grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="aspect-[3/4] overflow-hidden" style={{ borderRadius: "1px" }}>
                <img
                  src={COFFEE_IMG}
                  alt="Artisan coffee at Fables & Food"
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.05]"
                />
              </div>
              <div className="aspect-[3/4] overflow-hidden mt-8" style={{ borderRadius: "1px" }}>
                <img
                  src={PASTRY_IMG}
                  alt="Fresh pastries at Fables & Food"
                  className="w-full h-full object-cover transition-transform duration-700 hover:scale-[1.05]"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── HOURS & VISIT ── */}
      <section
        id="visit"
        className="py-24 md:py-32 relative overflow-hidden"
        style={{ background: "oklch(0.18 0.04 45)" }}
      >
        {/* Background image with overlay */}
        <div className="absolute inset-0 opacity-15">
          <img
            src={EXTERIOR_IMG}
            alt=""
            className="w-full h-full object-cover"
          />
        </div>

        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-16 lg:gap-24">
            {/* Hours */}
            <div ref={hoursRef} className="reveal">
              <p
                className="text-xs tracking-[0.3em] uppercase mb-4"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.72 0.14 65)",
                }}
              >
                When We're Open
              </p>
              <h2
                className="text-4xl font-bold mb-10"
                style={{
                  fontFamily: "var(--font-display)",
                  color: "oklch(0.97 0.018 78)",
                }}
              >
                Hours
              </h2>

              <div className="space-y-4">
                {[
                  { days: "Monday – Thursday", hours: "8:00 am – 6:00 pm" },
                  { days: "Friday – Saturday", hours: "8:00 am – 7:00 pm" },
                  { days: "Sunday", hours: "8:00 am – 6:00 pm" },
                ].map((row) => (
                  <div
                    key={row.days}
                    className="flex justify-between items-center py-4"
                    style={{ borderBottom: "1px solid oklch(0.97 0.018 78 / 0.12)" }}
                  >
                    <span
                      className="text-sm font-medium"
                      style={{
                        fontFamily: "var(--font-ui)",
                        color: "oklch(0.80 0.025 65)",
                      }}
                    >
                      {row.days}
                    </span>
                    <span
                      className="text-sm font-semibold"
                      style={{
                        fontFamily: "var(--font-ui)",
                        color: "oklch(0.72 0.14 65)",
                      }}
                    >
                      {row.hours}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Visit / Contact */}
            <div ref={visitRef} className="reveal" style={{ transitionDelay: "0.15s" }}>
              <p
                className="text-xs tracking-[0.3em] uppercase mb-4"
                style={{
                  fontFamily: "var(--font-ui)",
                  color: "oklch(0.72 0.14 65)",
                }}
              >
                Come Find Us
              </p>
              <h2
                className="text-4xl font-bold mb-10"
                style={{
                  fontFamily: "var(--font-display)",
                  color: "oklch(0.97 0.018 78)",
                }}
              >
                Visit
              </h2>

              <div className="space-y-6">
                <div className="flex gap-4 items-start">
                  <div
                    className="w-10 h-10 flex items-center justify-center shrink-0 mt-0.5"
                    style={{
                      background: "oklch(0.58 0.13 38 / 0.3)",
                      borderRadius: "2px",
                    }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="oklch(0.72 0.14 65)" strokeWidth="1.8">
                      <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                      <circle cx="12" cy="10" r="3" />
                    </svg>
                  </div>
                  <div>
                    <p
                      className="text-sm font-semibold mb-1"
                      style={{
                        fontFamily: "var(--font-ui)",
                        color: "oklch(0.97 0.018 78)",
                      }}
                    >
                      Address
                    </p>
                    <a
                      href="https://maps.google.com/?q=1016+Cardero+St,+Vancouver,+BC+V6G+2H1"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm leading-relaxed hover:underline"
                      style={{
                        fontFamily: "var(--font-body)",
                        color: "oklch(0.72 0.025 65)",
                      }}
                    >
                      1016 Cardero St<br />
                      Vancouver, BC V6G 2H1
                    </a>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div
                    className="w-10 h-10 flex items-center justify-center shrink-0 mt-0.5"
                    style={{
                      background: "oklch(0.58 0.13 38 / 0.3)",
                      borderRadius: "2px",
                    }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="oklch(0.72 0.14 65)" strokeWidth="1.8">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.62 3.38 2 2 0 0 1 3.6 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.6a16 16 0 0 0 6 6l.96-.96a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                  </div>
                  <div>
                    <p
                      className="text-sm font-semibold mb-1"
                      style={{
                        fontFamily: "var(--font-ui)",
                        color: "oklch(0.97 0.018 78)",
                      }}
                    >
                      Phone
                    </p>
                    <a
                      href="tel:+16047043572"
                      className="text-sm hover:underline"
                      style={{
                        fontFamily: "var(--font-body)",
                        color: "oklch(0.72 0.025 65)",
                      }}
                    >
                      +1 (604) 704-3572
                    </a>
                  </div>
                </div>

                <div className="flex gap-4 items-start">
                  <div
                    className="w-10 h-10 flex items-center justify-center shrink-0 mt-0.5"
                    style={{
                      background: "oklch(0.58 0.13 38 / 0.3)",
                      borderRadius: "2px",
                    }}
                  >
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="oklch(0.72 0.14 65)" strokeWidth="1.8">
                      <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                      <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                    </svg>
                  </div>
                  <div>
                    <p
                      className="text-sm font-semibold mb-1"
                      style={{
                        fontFamily: "var(--font-ui)",
                        color: "oklch(0.97 0.018 78)",
                      }}
                    >
                      Instagram
                    </p>
                    <a
                      href="https://www.instagram.com/fablesandfoodcafe/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm hover:underline"
                      style={{
                        fontFamily: "var(--font-body)",
                        color: "oklch(0.72 0.025 65)",
                      }}
                    >
                      @fablesandfoodcafe
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </section>

      <Footer />

      {/* Marquee animation */}
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
      `}</style>
    </div>
  );
}
