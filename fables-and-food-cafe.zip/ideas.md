# Fables & Food Café — Design Ideas

## Context
A newly opened neighbourhood café in Vancouver's West End (1016 Cardero St), inspired by fables and storytelling. Warm, community-oriented, cozy, with a narrative identity — "every fable has a flavour."

---

<response>
<idea>
**Design Movement:** Storybook Romanticism — editorial warmth meets hand-crafted intimacy

**Core Principles:**
- Narrative-first: every section tells part of a story, like chapters in a book
- Warmth over minimalism: rich textures, warm tones, layered depth
- Asymmetric editorial layouts: text and image interplay like magazine spreads
- Tactile feel: paper-like textures, ink-style typography

**Color Philosophy:**
- Parchment cream (#F5EDD8) as base — evokes aged paper and warmth
- Deep forest ink (#2C3E2D) for text — grounded, literary
- Burnt sienna (#C4622D) as accent — warmth of coffee, autumn leaves
- Dusty rose (#D4A5A5) as secondary accent — soft, inviting

**Layout Paradigm:**
- Asymmetric two-column layouts with large type on one side and imagery on the other
- Sections "turn like pages" — alternating left/right image-text compositions
- Generous vertical rhythm with large section headings

**Signature Elements:**
- Decorative serif drop caps and chapter-number ornaments
- Subtle paper grain texture overlay on backgrounds
- Thin ink-line botanical illustrations as dividers

**Interaction Philosophy:**
- Hover reveals — text fades in over images like turning a page
- Scroll-triggered fade-ups that feel like reading a book
- Smooth anchor navigation with no jarring jumps

**Animation:**
- Entrance animations: fade-up at 0.4s ease-out, staggered 60ms per item
- Image parallax on scroll (subtle, 20% offset)
- Nav links underline draws left-to-right on hover (200ms)

**Typography System:**
- Display: Playfair Display (serif, bold) — for headings and hero
- Body: Lora (serif) — warm, readable, literary
- Accent: DM Sans (sans-serif) — for labels, hours, small UI text
</idea>
<probability>0.08</probability>
</response>

<response>
<idea>
**Design Movement:** Scandinavian Folk Modernism — clean structure with organic warmth

**Core Principles:**
- Structured simplicity: clear grid, generous whitespace
- Natural materials palette: linen, wood, sage
- Playful folk motifs as decorative accents
- Calm and unhurried — no visual noise

**Color Philosophy:**
- Warm linen (#EDE8DF) as background
- Charcoal (#2A2A2A) for text
- Sage green (#7A9E7E) as primary accent
- Terracotta (#B5603A) as secondary accent

**Layout Paradigm:**
- Single-column with wide gutters on desktop
- Large section numbers as visual anchors
- Centered hero with asymmetric content sections below

**Signature Elements:**
- Thin-line folk pattern borders
- Rounded image frames with slight rotation
- Handwritten-style script for pull quotes

**Interaction Philosophy:**
- Gentle hover lifts on cards (translateY -4px)
- Clean, instant navigation
- Minimal animation — only purposeful transitions

**Animation:**
- Fade-in on scroll, 300ms ease-out
- Button scale 0.97 on active

**Typography System:**
- Display: Cormorant Garamond (elegant serif)
- Body: Source Serif 4 (readable, warm)
- UI: Space Grotesk (geometric sans)
</idea>
<probability>0.07</probability>
</response>

<response>
<idea>
**Design Movement:** Warm Literary Maximalism — richly layered, story-soaked, neighbourhood-proud

**Core Principles:**
- Abundance of warmth: deep earthy tones, layered imagery, rich typographic hierarchy
- Community-centred storytelling: the café as a character in the neighbourhood's story
- Textured depth: overlapping elements, subtle grain, warm shadows
- Confident asymmetry: no two sections feel the same

**Color Philosophy:**
- Deep espresso (#1E1410) as hero background — intimate, café-like
- Warm cream (#F7EDD5) for body sections — parchment warmth
- Amber gold (#D4900A) as accent — coffee, candlelight, warmth
- Muted sage (#8A9E7A) as secondary accent — Vancouver's greenery
- Dusty terracotta (#C4622D) for CTAs

**Layout Paradigm:**
- Full-bleed hero with large overlapping title and atmospheric image
- Staggered card grid for menu highlights — not uniform
- Diagonal section dividers to create visual flow
- Footer as a warm "closing chapter" with all info

**Signature Elements:**
- Large decorative quotation marks in amber gold
- Thin horizontal rules with small ornamental diamonds
- Warm vignette overlay on hero image

**Interaction Philosophy:**
- Cards lift and warm (subtle box-shadow increase) on hover
- CTA buttons have a warm amber glow on hover
- Smooth scroll with section fade-ins

**Animation:**
- Hero text: staggered word-by-word fade-up, 80ms intervals
- Section entrances: fade-up 40px → 0, 500ms ease-out
- Image hover: scale 1.03, 300ms ease-out

**Typography System:**
- Display: Playfair Display (bold, italic for hero)
- Body: Lora (warm, readable serif)
- UI/Labels: DM Sans (clean contrast to serifs)
</idea>
<probability>0.09</probability>
</response>

---

## Selected Design: Warm Literary Maximalism

Chosen for its alignment with the "Fables & Food" brand identity — rich storytelling, neighbourhood warmth, and the cozy intimacy of a café that believes every flavour has a tale to tell.
